'use client';

import { useEffect, useRef } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAdminStore } from '@/lib/admin-store';
import { AdminPanel } from './AdminPanel';

export function AdminGate() {
  const { isAdmin } = useAdminStore();
  const searchParams = useSearchParams();
  const showAdmin = searchParams.get('admin') === '1' || isAdmin;
  const prevDarkClass = useRef<boolean | null>(null);

  // FORCE: remove 'dark' class from <html> so no dark mode styles apply in admin
  useEffect(() => {
    if (!showAdmin) return;

    const html = document.documentElement;
    prevDarkClass.current = html.classList.contains('dark');

    if (prevDarkClass.current) {
      html.classList.remove('dark');
    }

    return () => {
      if (prevDarkClass.current) {
        html.classList.add('dark');
      }
      prevDarkClass.current = null;
    };
  }, [showAdmin]);

  if (!showAdmin) return null;

  return (
    <div className="fixed inset-0 z-50" style={{ backgroundColor: '#FAFAF7' }}>
      <AdminPanel />
    </div>
  );
}
